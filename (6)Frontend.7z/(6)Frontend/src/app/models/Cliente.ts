export interface Cliente {
    idCliente: number,
    nombres: string,
    apellidos: string,
    fecha: Date,
    direccion: string,
    celular: string,
    email: string,
    
  }
