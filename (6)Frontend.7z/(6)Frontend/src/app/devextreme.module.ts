import {NgModule} from '@angular/core';
import { DxDataGridModule, DxTemplateModule, DxBulletModule, DxTextAreaModule, DxFormModule,DxButtonModule } from 'devextreme-angular';

@NgModule({
  exports: [
    DxDataGridModule, DxTemplateModule, DxBulletModule, DxTextAreaModule, DxFormModule,DxButtonModule,
  ]
})
export class DevextremeModule { }