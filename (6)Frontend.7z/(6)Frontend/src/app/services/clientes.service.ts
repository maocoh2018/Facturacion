import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';


@Injectable({
    providedIn: 'root'
  })
  export class ClienteService {
  
    constructor(private http:HttpClient)  { }  
  
    public obtenerDatos(): Observable<any[]> {
      return this.http.get<any[]>(environment.urlApi + '/Api/Facturacion/GetCliente');
    }   

    public registrar(modelo: any): Observable<any> {
      return this.http.post<any>(environment.urlApi + '/Api/Facturacion/AddCliente', modelo, {});
    }
  
    public update(modelo: any): Observable<any> {
      return this.http.post<any>(environment.urlApi + '/Api/Facturacion/UpdCliente', modelo, {});    
    }
    public delete(id: number): Observable<any> {    
      return this.http.post<any>(environment.urlApi + '/Api/Facturacion/DeleteCliente', id, {});    
    }
  
  }
  