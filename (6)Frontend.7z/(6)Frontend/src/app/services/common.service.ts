import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor(private http:HttpClient)  { }

  
  public obtenerProductos(): Observable<any> {
    return this.http.get<any>(environment.urlApi + '/Api/Facturacion/GetProducto');
  }

  public obtenerFacturas(): Observable<any> {
    return this.http.get<any>(environment.urlApi + '/Api/Facturacion/GetFacturas');
  }
}
  
  

