import { Component, OnInit, ViewChild } from '@angular/core';
import { finalize } from 'rxjs/operators';

// DevExtreme
import { DxDataGridComponent } from 'devextreme-angular';
import notify from 'devextreme/ui/notify';
import { Cliente } from 'src/app/models/Cliente';
import { ClienteService } from 'src/app/services/clientes.service';




@Component({
  selector: 'app-componente1',
  templateUrl: './componente1.component.html',
  styleUrls: ['./componente1.component.css']
})
export class Componente1Component implements OnInit {

  dataSource:any [] = []; 
  
  loadingVisible = true;

  constructor(
    private clienteService: ClienteService,
    
  ) { }

  ngOnInit() {
    this.obtenerDatos();
}
  obtenerDatos() {
    this.clienteService.obtenerDatos().pipe(
      finalize(() => {
        console.log('Servicio completado correctamente');        
      }
      )).subscribe(resp => {        
        this.dataSource = resp;     
        console.log(this.dataSource);
      });
  }

  
  onRowInserted(event:any) {    
    
    this.clienteService.registrar(event.data).pipe(
      finalize(() => {
        console.log('Servicio completado correctamente');        
      }
      )).subscribe(resp => {        
        this.dataSource = resp;     
        notify(
              { message: 'cliente registrado correctamente', width: 500 },
              resp ? 
              "success": "error"
              );              
        this.obtenerDatos();
      }), () => notify({ message: "Ha ocurrido un error al realizar la petición"}, "error");
    
  }

  onRowRemoved(event:any) {    
    this.clienteService.delete(event.data).pipe(
      finalize(() => {
        console.log('Servicio completado correctamente');        
      }
      )).subscribe(resp => {        
        this.dataSource = resp;     
        notify({ message: 'cliente eliminado correctamente', width: 500 }, resp ? "success": "error");
        this.obtenerDatos();
      }), () => notify({ message: "Ha ocurrido un error al realizar la petición"}, "error");
   
  }

  onRowUpdated(event:any) {  
    this.clienteService.update(event.data).pipe(
      finalize(() => {
        console.log('Servicio completado correctamente');        
      }
      )).subscribe(resp => {        
        this.dataSource = resp;     
        notify({ message: 'cliente actualizado correctamente', width: 500 },resp ? "success": "error");
        this.obtenerDatos();
      }), () => notify({ message: "Ha ocurrido un error al realizar la petición"}, "error");
  }


}
