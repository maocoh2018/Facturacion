import { Component, OnInit, NgModule, Pipe, PipeTransform, enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import {
  DxDataGridModule,
  DxBulletModule,
  DxTemplateModule
} from 'devextreme-angular';
import DataSource from 'devextreme/data/data_source';
import { finalize } from 'rxjs/operators';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-componente3',
  templateUrl: './componente3.component.html',
  styleUrls: ['./componente3.component.css']
})
export class Componente3Component implements OnInit {

  dataSource: any[]=[];
  
  collapsed = false;
  
  constructor(private serviceCliente: CommonService) { }

  ngOnInit(): void {
    this.obtenerFacturas();
  }
  obtenerFacturas() {
    this.serviceCliente.obtenerFacturas().pipe(
      finalize(() => {
        console.log('Servicio completado correctamente');
      }
      )).subscribe(resp => {
        this.dataSource = resp;
        console.log(this.dataSource);
      });
  }
}
